// //partie 01
// //declarer les variables
// let scoreGlobale = [0, 0];
// let scoreEnCours = 0;
// let jouerActif = 1
// let joueur =true;
//
// //PARTIR 2//Initialisation du jeu
//
// // document.getElementById(`score-1`).textContent = '0';
// // document.getElementById(`score-2`).textContent = '0';
// // document.getElementById(`encours-1`).textContent = '0';
// // document.getElementById(`encours-2`).textContent = '0';
// //on appelle la fonction initialisation jeu
// initialiseJeu();
//
// // PARTIE 03
// //on cible le bouton
// let btnLancezleDe = document.querySelector(`.btn-lancer`);
// btnLancezleDe.addEventListener('click', function () {
//     //simuler le lance du DE
//     let de = Math.floor(Math.random() * 6) + 1;
//     //mettre a jour limage di Dé
//     let domDe = document.querySelector('.de');
//     domDe.style.display = 'block';
//     domDe.src = `resources/images/de-${de}.png`;
//     //
// //on met a jour le score
//     scoreEnCours += de;
//     document.getElementById(`encours-${jouerActif}`).textContent = scoreEnCours;
// });
// //PARTIE 3
// //GESTION DU CLIQUE SUR LE BOUTON lancez le De
// //on cible le bouton par la classe
// let btnLancezLeDe = document.querySelector(`.btn-lancer`);
// //on attache levenement a un click
// btnLancezleDe.addEventListener('click', () => {
//     if (joueur) {
//         let de = Math.floor(Math.random() * 6) + 1;
//         let domDe = document.querySelector('.de');
//         domDe.src = `resources/images/de-${de}.png`;
//         if (de !== 1) {
//             scoreEnCours += de;
//             document.getElementById(`encours-${jouerActif}`).textContent = scoreEnCours;
//         } else {
//             //on appele la fonction joueur suivant
//             joueurSuivant();
//             // jouerActif===1 ? jouerActif=2 : jouerActif=1;
//             // scoreEnCours=0;
//             // document.getElementById(`encours-${jouerActif}`).textContent=scoreEnCours;
//             // document.querySelector('joueur-1-panel').classList.toggle('active')  ;
//             // document.querySelector('joueur-2-panel').classList.toggle('active')  ;
//             // document.querySelector('.de').style.display='none';
//
//         }
//
//     }
// });
// // PARTIE 04 //gerer le click sur le bouton commutez
// let btncommutez=document.querySelector('.btn-commuter');
// btncommutez.addEventListener('click',()=>{
//     if (joueur) {
// //lors de la commutation on met a jours le tableau du score global
//         // le tableau debute par 0
//         scoreGlobale[jouerActif - 1] += scoreEnCours;
//         //on met a jour le score global
//         document.getElementById(`score-${jouerActif}`).textContent = scoreGlobale[jouerActif - 1];
//         if (scoreGlobale[jouerActif - 1] >= 100) {
//             document.getElementById(`nom-${jouerActif}`).textContent = 'BRAVO!!!!';
//             document.querySelector(`.joueur-${jouerActif}`).classList.add('vainqueur');
//             document.querySelector(`.joueur-${jouerActif}`).classList.remove('active');
//             document.querySelector('.de').style.display = 'none';
//         }
// //on appelle la fonction joueur suivant
//         joueurSuivant();
//     }
// });
// //implementer la fonction joueur suivant
// function joueurSuivant() {
//     jouerActif===1? jouerActif=2:jouerActif=1;
//     scoreEnCours=0;
//     document.getElementById(`encours-${jouerActif}`).textContent='0';
//     document.querySelector('joueur-1-panel').classList.toggle('active') ;
//     document.querySelector('joueur-2-panel').classList.toggle('active') ;
//     document.querySelector('.de').style.display='none';
//
// }
// // 6// PARTIE 6
// //GESTION DU CLIC sur le click nouveau jeu
//
//
// let btnNouveaujeu=document.querySelector('.btn-nouveau');
// btnNouveaujeu.addEventListener('click',()=>{
//  //on initialise tous les composants du Gui conformement
//  //a un jeu qui demarre nouvellement
//  //    scoreGlobale = [0, 0];
//  //     scoreEnCours = 0;
//  //     jouerActif = 1;
//  //     document.querySelector(`.de`).style.display='none';
//  //     document.getElementById(`score-1`).textContent='0';
//  //     document.getElementById(`score-2`).textContent='0';
//  //     document.getElementById(`encours-1`).textContent='0';
//  //     document.getElementById(`encours-2`).textContent='0';
//     //on appele la fonction initilisation jeu
//     initialiseJeu();
//
// });
//
// //PARTIE 07====>IMPLANTION DE FONCTION initialisation jeu
//
// function initialiseJeu() {
//     scoreGlobale = [0, 0];
//     scoreEnCours = 0;
//     jouerActif = 1;
//     document.querySelector(`.de`).style.display='none';
//     document.getElementById(`score-1`).textContent='0';
//     document.getElementById(`score-2`).textContent='0';
//     document.getElementById(`encours-1`).textContent='0';
//     document.getElementById(`encours-2`).textContent='0';
//     document.getElementById(`nom-1`).textContent='joueur1';
//     document.getElementById(`nom-2`).textContent='joueur2';
//     document.getElementById(`.joueur1-panel`).classList.remove('vainqueur');
//     document.getElementById(`.joueur2-panel`).classList.remove('vainqueur');
//     document.getElementById(`.joueur2-panel`).classList.remove('active');
//     document.getElementById(`.joueur1-panel`).classList.add('active');
// }
//
//
//

//     PARTIE 01
let scoresGlobals = [0, 0];
let scoreEnCours = 0;
let joueurActif = 1;
let jouer = true;

//    PARTIE 02
initiliseLeJeu();

//PARTIE3
let btnLancezLeDe = document.querySelector(`.btn-lancer`);
btnLancezLeDe.addEventListener('click', () =>{

    if (jouer){
        let de = Math.floor(Math.random() * 6) + 1;
        let domDe = document.querySelector('.de');
        domDe.style.display = 'block';
        domDe.src = `resources/images/de-${de}.png`;

        if (de !== 1){
            scoreEnCours += de;
            document.getElementById(`encours-${joueurActif}`).textContent = scoreEnCours;
        } else{
            joueurSuivant()
    }
}
});

//       PARTIE 04
let btnCommutez = document.querySelector('.btn-commuter');
btnCommutez.addEventListener('click', () => {

    if (jouer){
        scoresGlobals[joueurActif - 1] += scoreEnCours;
        document.getElementById(`score-${joueurActif}`).textContent=scoresGlobals[joueurActif-1];

        if (scoresGlobals[joueurActif - 1] >= 100) {
            document.getElementById(`nom-${joueurActif}`).textContent = 'Bravo !!!';
            document.querySelector('.de').style.display = 'none';
            document.querySelector(`.joueur-${joueurActif}-panel`).classList.add('vainqueur');
            document.querySelector(`.joueur-${joueurActif}-panel`).classList.remove('active');
        } else {
            joueurSuivant()
    }
    }
});

//PARTIE5
function joueurSuivant() {
    joueurActif === 1 ? joueurActif = 2 : joueurActif = 1;
    scoreEnCours = 0;
    document.getElementById(`encours-${joueurActif}`).textContent = '0';
    document.querySelector('.joueur-1-panel').classList.toggle('active');
    document.querySelector('.joueur-2-panel').classList.toggle('active');
    document.querySelector('.de').style.display = 'none';
}

//PARTIE6
let btnNouveauJeu = document.querySelector('.btn-nouveau');
btnNouveauJeu.addEventListener('click',() => {
    initiliseLeJeu();
});

//PARTIE7
function initiliseLeJeu() {
        scoresGlobals = [0, 0];
        scoreEnCours = 0;
        joueurActif = 1;

        document.querySelector('.de').style.display = 'none';
        document.getElementById('score-1').textContent = '0';
        document.getElementById('score-2').textContent = '0';
        document.getElementById('encours-1').textContent = '0';
        document.getElementById('encours-2').textContent = '0';
        document.getElementById('nom-1').textContent = 'Joueur 1';
        document.getElementById('nom-2').textContent = 'Joueur 2';
        document.querySelector('.joueur-1-panel').classList.remove('vainqueur');
        document.querySelector('.joueur-2-panel').classList.remove('vainqueur');
        document.querySelector('.joueur-2-panel').classList.remove('active');
        document.querySelector('.joueur-1-panel').classList.add('active');
}

//
//
//
